# -*- coding: utf-8 -*-

__version__ = '2.6'
__author__ = 'Fachrizal Oktavian'
__author_email__ = 'fachri0510@gmail.com'
__release_date__ = 'December 15th, 2016'
