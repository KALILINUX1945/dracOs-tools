##2. - 15/12/2016

* Miss download tarbal version

##2.5 - 15/12/2016

* Fixed configure on Pypi installer.

##1.4, 1.5 and 1.6 - 14/12/2016

* Fixed Pypi installer.

##1.3 - 13/12/2016

* Now compatible with Python 3 and support US Standard PEP8 encodings
* Supported to Pypi installer.

##1.0 - 04/12/2016

* Initial launch
